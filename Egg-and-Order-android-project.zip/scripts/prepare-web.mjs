import { cpSync, mkdirSync, rmSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = resolve(root, 'www');
const files = ['index.html', 'style.css', 'game.js', 'manifest.webmanifest', 'sw.js'];

rmSync(output, { recursive: true, force: true });
mkdirSync(output, { recursive: true });
files.forEach(file => cpSync(resolve(root, file), resolve(output, file)));
cpSync(resolve(root, 'assets'), resolve(output, 'assets'), { recursive: true });
console.log(`Prepared ${files.length} web files and ${resolve(output, 'assets')}`);