# Android packaging

Egg & Order is already set up to run as a standalone PWA and as a Capacitor Android app.
The native Android project has been generated in `android/`, with the branded launcher icon and splash copied into its resources.

## GitHub Actions

The workflow at `.github/workflows/android-build.yml` builds both artifacts automatically on pushes to `main`, pull requests, or a manual workflow run:

- `app-debug.apk` for device testing
- `app-release.aab` for Google Play upload

Without signing secrets, the AAB is unsigned but still useful as a CI build artifact. For a Play-ready signed AAB, add these repository secrets:

```text
ANDROID_KEYSTORE_BASE64
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_ALIAS
ANDROID_KEY_PASSWORD
```

The workflow decodes the keystore only inside the temporary GitHub Actions runner and does not commit it to the repository.

## Install and open Android Studio

```bash
npm install
npm run cap:add:android
npm run cap:sync
npm run cap:open
```

Run `npm run cap:add:android` only once. It creates the native `android/` project from `capacitor.config.json`.

## Build an APK or Play Store bundle

In Android Studio:

1. Let Gradle finish syncing.
2. Use **Build → Generate App Bundles or APKs → Generate Signed Bundle / APK**.
3. Choose **Android App Bundle** for Google Play or **APK** for direct testing.
4. Set the package id to `com.sunnyacres.eggandorder` if Android Studio asks for it.

The app is locked to portrait mode by the web manifest and uses the same `assets/splash.svg` branding for the native splash source. The PWA uses the generated PNG icon files in `assets/`; those same `assets/icon.png` and `assets/splash.png` files are ready to import into the generated Android resources if you customize the native launcher artwork.

## Updating the Android build

After changing the web game:

```bash
npm run cap:sync
npm run cap:open
```

The generated `android/` project is now present in this workspace. If you regenerate it from scratch, rerun `npm run cap:add:android` once and then use `npm run cap:sync` for future web changes.

## Build note for this workspace

The project generation and Capacitor sync completed successfully here. The first `assembleDebug` attempt could not finish because this workspace does not have an Android SDK or `adb` installed. On a machine with Android Studio and the Android SDK configured, run:

```bash
cd android
./gradlew assembleDebug
```

The debug APK will be written to `android/app/build/outputs/apk/debug/app-debug.apk`.