(() => {
  'use strict';

  const canvas = document.getElementById('gameCanvas');
  const ctx = canvas.getContext('2d');
  const W = 360, H = 640;
  let scale = 1, running = false, lastTime = 0, soundOn = true;
  const $ = (id) => document.getElementById(id);

  const state = {
    coins: 48, corn: 0, eggs: 0, level: 1, eggValue: 8, chickenTier: 1,
    speedLevel: 0, capacityLevel: 0, patchLevel: 0,
    player: { x: 180, y: 490, bob: 0, dir: 1 },
    joystick: { x: 0, y: 0, active: false, pointerId: null },
    crops: [], eggsOnGround: [], particles: [], floats: [], dust: [],
    feedPulse: 0, marketPulse: 0, chickenBlink: 0, actionCooldown: 0,
    introHint: true, harvestCount: 0, totalEggs: 0, sellCount: 0,
  };

  const patch = { x: 56, y: 249, w: 135, h: 116 };
  const chicken = { x: 264, y: 277, r: 38 };
  const market = { x: 262, y: 413, w: 76, h: 83 };
  const fence = { x: 27, y: 205, w: 306, h: 337 };
  const action = { label: $('actionLabel'), icon: $('actionIcon'), button: $('actionButton') };

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
  }
  window.addEventListener('load', () => {
    window.setTimeout(() => $('appSplash')?.classList.add('is-hidden'), 650);
  });

  function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    scale = rect.width / W;
    ctx.setTransform(dpr * scale, 0, 0, dpr * scale, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  function seededCrops() {
    state.crops = [];
    for (let i = 0; i < 14; i++) {
      const col = i % 5, row = Math.floor(i / 5);
      state.crops.push({
        x: patch.x + 17 + col * 25 + (row % 2 ? 5 : 0),
        y: patch.y + 21 + row * 25,
        phase: (i * 0.34) % 1.8,
        ready: false, wobble: Math.random() * Math.PI * 2,
      });
    }
  }
  seededCrops();

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
  function nearestReadyCrop() {
    return state.crops.filter(c => c.ready).sort((a, b) => dist(state.player, a) - dist(state.player, b))[0];
  }
  function nearPatch() { return state.player.x > patch.x - 32 && state.player.x < patch.x + patch.w + 32 && state.player.y > patch.y - 35 && state.player.y < patch.y + patch.h + 35; }
  function nearChicken() { return dist(state.player, chicken) < 75; }
  function nearMarket() { return state.player.x > market.x - 50 && state.player.x < market.x + market.w + 30 && state.player.y > market.y - 52 && state.player.y < market.y + market.h + 35; }

  function addToast(text) {
    const el = document.createElement('div');
    el.className = 'toast'; el.textContent = text; $('toastStack').appendChild(el);
    setTimeout(() => el.remove(), 2100);
  }
  function floatText(text, x, y, color = '#fff') { state.floats.push({ text, x, y, color, life: 1 }); }
  function particleBurst(x, y, color, count = 8) {
    for (let i = 0; i < count; i++) state.particles.push({ x, y, vx: (Math.random() - .5) * 50, vy: -20 - Math.random() * 50, life: .7 + Math.random() * .4, color, size: 2 + Math.random() * 3 });
  }
  function beep(type = 'pop') {
    if (!soundOn) return;
    try {
      const ac = beep.ac || (beep.ac = new (window.AudioContext || window.webkitAudioContext)());
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = type === 'coin' ? 'triangle' : 'sine'; o.frequency.value = type === 'coin' ? 760 : 490;
      g.gain.setValueAtTime(.035, ac.currentTime); g.gain.exponentialRampToValueAtTime(.001, ac.currentTime + .12);
      o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + .13);
    } catch (_) {}
  }

  function harvest() {
    if (!nearPatch()) { addToast('Walk closer to the corn patch'); return; }
    const room = cornCapacity() - state.corn;
    const ready = state.crops.filter(c => c.ready);
    const count = Math.min(room, ready.length);
    if (!count) { addToast(room <= 0 ? 'Your corn basket is full!' : 'The corn is still growing…'); return; }
    ready.slice(0, count).forEach(c => { c.ready = false; c.phase = 0; floatText('+1 corn', c.x, c.y - 12, '#fff6c7'); particleBurst(c.x, c.y, '#ffd365', 5); });
    state.corn += count; state.harvestCount += count; state.introHint = false; beep();
    if (count > 1) addToast(`Harvested ${count} ears of corn!`);
    updateHUD();
  }
  function feedChicken() {
    if (!nearChicken()) { addToast('Walk closer to the Giant Hen'); return; }
    if (!state.corn) { addToast('Bring corn to the Giant Hen first'); return; }
    const eggsWaiting = state.eggsOnGround.filter(e => !e.collected).length;
    const laid = Math.min(2 + state.chickenTier, 5 - state.eggs - eggsWaiting);
    if (!laid) { addToast('Collect your eggs before feeding again'); return; }
    state.corn--; state.totalEggs += laid; state.feedPulse = 1;
    for (let i = 0; i < laid; i++) {
      const a = (i / laid) * Math.PI + .15, egg = { x: chicken.x + Math.cos(a) * 31, y: chicken.y + 43 + Math.sin(a) * 7, bob: Math.random() * 6, collected: false };
      state.eggsOnGround.push(egg);
    }
    floatText(`+${laid} eggs`, chicken.x, chicken.y - 57, state.chickenTier > 1 ? '#ffe18a' : '#fff');
    particleBurst(chicken.x, chicken.y - 36, state.chickenTier > 1 ? '#ffe08b' : '#fff9dc', 12);
    addToast(state.chickenTier > 1 ? 'Golden eggs! Nice work.' : 'The Giant Hen laid eggs!');
    beep('coin'); updateHUD();
  }
  function collectEggs() {
    const nearby = state.eggsOnGround.filter(e => !e.collected && dist(state.player, e) < 58);
    if (!nearby.length) return false;
    const room = 5 - state.eggs;
    const take = Math.min(room, nearby.length);
    if (!take) { addToast('Your egg basket is full! Sell them at the stand.'); return true; }
    nearby.slice(0, take).forEach(e => { e.collected = true; floatText('+1 egg', e.x, e.y - 12, '#fff'); particleBurst(e.x, e.y, '#fff5c4', 4); });
    state.eggs += take; beep(); updateHUD();
    if (state.eggs >= 5) addToast('Basket full — take them to market!');
    return true;
  }
  function sellEggs() {
    if (!nearMarket()) { addToast('Walk over to the Market Stand'); return; }
    if (!state.eggs) { addToast('No eggs to sell yet'); return; }
    const earned = state.eggs * state.eggValue;
    const sold = state.eggs; state.eggs = 0; state.coins += earned; state.sellCount += sold; state.marketPulse = 1;
    floatText(`+${earned} coins`, market.x + 4, market.y - 14, '#fff4a8'); particleBurst(market.x, market.y + 5, '#ffce57', 14);
    addToast(`Sold ${sold} eggs for ${earned} coins!`); beep('coin'); updateHUD();
    if (state.sellCount >= 10 && state.level < 2) { state.level = 2; addToast('Farm Level 2 unlocked!'); }
  }
  function actionNow() {
    if (nearMarket() && state.eggs) return sellEggs();
    if (nearChicken() && state.corn) return feedChicken();
    if (collectEggs()) return;
    if (nearPatch()) return harvest();
    addToast('Use the joystick to explore your farm');
  }

  function cornCapacity() { return 10 + state.capacityLevel * 5; }
  function cropGrowRate() { return .09 + state.patchLevel * .045; }
  function updateHUD() {
    $('coinValue').textContent = state.coins;
    $('cornValue').textContent = `${state.corn}/${cornCapacity()}`;
    $('eggValue').textContent = `${state.eggs}/5`;
    $('levelValue').textContent = state.level;
    $('modalCoins').textContent = state.coins;
    $('speedCost').textContent = 40 + state.speedLevel * 50;
    $('capacityCost').textContent = 55 + state.capacityLevel * 65;
    $('patchCost').textContent = 70 + state.patchLevel * 80;
    $('chickenCost').textContent = 120 + (state.chickenTier - 1) * 160;
    document.querySelectorAll('.upgrade-card').forEach(card => {
      const type = card.dataset.upgrade;
      const cost = upgradeCost(type);
      card.classList.toggle('can-buy', state.coins >= cost && !isMaxed(type));
      card.style.opacity = isMaxed(type) ? '.5' : '1';
    });
  }
  function upgradeCost(type) {
    if (type === 'speed') return 40 + state.speedLevel * 50;
    if (type === 'capacity') return 55 + state.capacityLevel * 65;
    if (type === 'patch') return 70 + state.patchLevel * 80;
    return 120 + (state.chickenTier - 1) * 160;
  }
  function isMaxed(type) { return type === 'speed' ? state.speedLevel >= 3 : type === 'capacity' ? state.capacityLevel >= 3 : type === 'patch' ? state.patchLevel >= 3 : state.chickenTier >= 2; }
  function buyUpgrade(type) {
    if (isMaxed(type)) { addToast('That upgrade is fully powered up'); return; }
    const cost = upgradeCost(type);
    if (state.coins < cost) { addToast(`You need ${cost - state.coins} more coins`); return; }
    state.coins -= cost;
    if (type === 'speed') state.speedLevel++;
    if (type === 'capacity') state.capacityLevel++;
    if (type === 'patch') state.patchLevel++;
    if (type === 'chicken') { state.chickenTier++; state.eggValue = 24; }
    addToast('Upgrade unlocked!'); particleBurst(180, 130, '#ffd268', 16); beep('coin'); updateHUD();
  }

  function update(dt) {
    if (!running) return;
    const j = state.joystick;
    const speed = 84 + state.speedLevel * 15;
    if (j.active || Math.abs(j.x) + Math.abs(j.y) > .01) {
      state.player.x += j.x * speed * dt; state.player.y += j.y * speed * dt;
      if (Math.abs(j.x) > .1) state.player.dir = j.x > 0 ? 1 : -1;
      state.player.bob += dt * 12;
      if (Math.random() < dt * 5) state.dust.push({ x: state.player.x, y: state.player.y + 17, life: .4, size: 2 + Math.random() * 2 });
    }
    state.player.x = clamp(state.player.x, fence.x + 18, fence.x + fence.w - 18);
    state.player.y = clamp(state.player.y, fence.y + 40, fence.y + fence.h - 20);
    state.crops.forEach(c => { if (!c.ready) { c.phase += dt * cropGrowRate(); if (c.phase >= 1) c.ready = true; } c.wobble += dt * 2; });
    state.eggsOnGround = state.eggsOnGround.filter(e => !e.collected);
    state.feedPulse = Math.max(0, state.feedPulse - dt * 2.3);
    state.marketPulse = Math.max(0, state.marketPulse - dt * 2.6);
    state.chickenBlink -= dt;
    if (state.chickenBlink < -2.5 && Math.random() < dt * .8) state.chickenBlink = .18;
    state.actionCooldown = Math.max(0, state.actionCooldown - dt);
    state.particles.forEach(p => { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 70 * dt; p.life -= dt; });
    state.particles = state.particles.filter(p => p.life > 0);
    state.floats.forEach(f => { f.y -= 22 * dt; f.life -= dt; });
    state.floats = state.floats.filter(f => f.life > 0);
    state.dust.forEach(d => { d.life -= dt; d.size += dt * 4; });
    state.dust = state.dust.filter(d => d.life > 0);
    if (nearMarket() && state.eggs && state.actionCooldown <= 0) { sellEggs(); state.actionCooldown = 1.2; }
    updateContext();
  }
  function updateContext() {
    let label = 'GO', icon = '✦', green = false, hint = state.introHint ? 'Grow some corn, farmer!' : 'Keep the farm moving!';
    if (nearMarket() && state.eggs) { label = 'SELL'; icon = '◉'; green = true; hint = 'The market is ready for your eggs'; }
    else if (nearChicken() && state.corn) { label = 'FEED'; icon = '♥'; hint = 'Feed the Giant Hen'; }
    else if (state.eggsOnGround.some(e => !e.collected && dist(state.player, e) < 58)) { label = 'COLLECT'; icon = '🥚'; green = true; hint = 'Eggs are ready to collect'; }
    else if (nearPatch()) { label = 'HARVEST'; icon = '✂'; hint = state.corn >= cornCapacity() ? 'Your basket is full' : 'Tap to harvest the corn'; }
    action.label.textContent = label; action.icon.textContent = icon; action.button.classList.toggle('green', green);
    $('hintText').textContent = hint;
  }

  function roundedRect(x, y, w, h, r, fill, stroke) {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r); if (fill) { ctx.fillStyle = fill; ctx.fill(); } if (stroke) { ctx.strokeStyle = stroke; ctx.stroke(); }
  }
  function draw() {
    ctx.clearRect(0, 0, W, H);
    drawBackground(); drawFarm(); drawPatch(); drawMarket(); drawChicken(); drawEggs(); drawCrops(); drawPlayer(); drawParticles(); drawFloats();
  }
  function drawBackground() {
    const grad = ctx.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, '#bde8f1'); grad.addColorStop(.34, '#d8f1d7'); grad.addColorStop(1, '#a4d49a'); ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#9ed7e9'; ctx.globalAlpha = .52;
    [[36,190,38],[126,182,25],[295,185,42],[342,226,28]].forEach(([x,y,r]) => { ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill(); });
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(255,255,255,.5)'; [[24,178,18],[48,178,23],[119,174,19],[137,174,25],[286,174,22],[312,174,26]].forEach(([x,y,r]) => { ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill(); });
  }
  function drawFarm() {
    ctx.save();
    ctx.fillStyle = '#8bc47f'; ctx.fillRect(0, 204, W, H - 204);
    ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(0, 204, W, 2);
    // soft field paths
    ctx.fillStyle = '#b8dc9a'; ctx.beginPath(); ctx.ellipse(183, 390, 139, 46, -.08, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#bedfa5'; ctx.beginPath(); ctx.ellipse(201, 526, 140, 40, .02, 0, Math.PI*2); ctx.fill();
    // fence shadow and rails
    ctx.strokeStyle = 'rgba(72,110,74,.2)'; ctx.lineWidth = 7; ctx.strokeRect(fence.x, fence.y, fence.w, fence.h);
    ctx.strokeStyle = '#f5d39b'; ctx.lineWidth = 4;
    ctx.strokeRect(fence.x, fence.y, fence.w, fence.h);
    ctx.strokeStyle = '#ffe8b9'; ctx.lineWidth = 2; ctx.strokeRect(fence.x, fence.y + 12, fence.w, fence.h - 12);
    for (let x = fence.x + 4; x < fence.x + fence.w; x += 22) { ctx.fillStyle = '#edc488'; roundedRect(x - 3, fence.y - 3, 6, 15, 3, '#f7d59c'); roundedRect(x - 3, fence.y + fence.h - 7, 6, 15, 3, '#e9bd78'); }
    ctx.restore();
    ctx.fillStyle = '#648b72'; ctx.font = '800 9px DM Sans'; ctx.textAlign = 'center'; ctx.letterSpacing = '1px'; ctx.fillText('SUNNY ACRES', 180, 224);
  }
  function drawPatch() {
    ctx.save();
    roundedRect(patch.x - 8, patch.y - 7, patch.w + 16, patch.h + 14, 15, '#9a6f47');
    roundedRect(patch.x - 2, patch.y - 2, patch.w + 4, patch.h + 4, 12, '#b78355');
    for (let y = patch.y + 12; y < patch.y + patch.h; y += 18) { ctx.strokeStyle = 'rgba(118,78,49,.36)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(patch.x, y); ctx.lineTo(patch.x + patch.w, y); ctx.stroke(); }
    ctx.fillStyle = 'rgba(255,255,255,.65)'; ctx.font = '800 9px DM Sans'; ctx.textAlign = 'left'; ctx.fillText('CORN PATCH', patch.x + 4, patch.y - 14);
    ctx.restore();
  }
  function drawCrops() {
    state.crops.forEach(c => {
      const sway = Math.sin(c.wobble) * (c.ready ? 1.7 : .7);
      ctx.save(); ctx.translate(c.x, c.y);
      ctx.strokeStyle = c.ready ? '#3d9562' : '#65a56d'; ctx.lineWidth = 2.4; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(0, 10); ctx.lineTo(sway, -7); ctx.stroke();
      ctx.fillStyle = c.ready ? '#4ca969' : '#74b977'; ctx.beginPath(); ctx.ellipse(-4 + sway, -3, 5, 2.2, -.4, 0, Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.ellipse(4 + sway, 1, 5, 2.2, .4, 0, Math.PI*2); ctx.fill();
      if (c.ready) { ctx.fillStyle = '#ffd25e'; ctx.strokeStyle = '#db9e3e'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(sway, -10, 4.5, 7.5, -.1, 0, Math.PI*2); ctx.fill(); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,.65)'; ctx.beginPath(); ctx.ellipse(sway - 1.3, -13, 1, 2.4, 0, 0, Math.PI*2); ctx.fill(); }
      ctx.restore();
    });
  }
  function drawChicken() {
    ctx.save(); const bounce = state.feedPulse > 0 ? Math.sin(state.feedPulse * 20) * 4 : 0; ctx.translate(chicken.x, chicken.y + bounce);
    ctx.fillStyle = 'rgba(69,110,70,.18)'; ctx.beginPath(); ctx.ellipse(0, 40, 44, 10, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = state.chickenTier > 1 ? '#ffe4a1' : '#fff4d7'; ctx.beginPath(); ctx.ellipse(0, 3, 31, 37, 0, 0, Math.PI*2); ctx.fill(); ctx.strokeStyle = state.chickenTier > 1 ? '#eab94e' : '#dbb875'; ctx.lineWidth = 2; ctx.stroke();
    ctx.fillStyle = state.chickenTier > 1 ? '#ffd064' : '#fff7e6'; ctx.beginPath(); ctx.arc(0, -29, 25, 0, Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#e8624e'; ctx.beginPath(); ctx.arc(-6, -53, 5, 0, Math.PI*2); ctx.arc(3, -54, 6, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#f0a948'; ctx.beginPath(); ctx.moveTo(22, -28); ctx.lineTo(37, -22); ctx.lineTo(22, -16); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2e4448'; ctx.beginPath(); if (state.chickenBlink > 0) { ctx.rect(-14,-33,6,1.5); ctx.rect(7,-33,6,1.5); } else { ctx.arc(-11,-33,2.4,0,Math.PI*2); ctx.arc(10,-33,2.4,0,Math.PI*2); } ctx.fill();
    ctx.fillStyle = state.chickenTier > 1 ? '#edb838' : '#ed8871'; ctx.beginPath(); ctx.ellipse(-4, -19, 4, 6, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.8)'; ctx.font = '800 9px DM Sans'; ctx.textAlign = 'center'; ctx.fillText(state.chickenTier > 1 ? 'GOLDEN HEN' : 'GIANT HEN', 0, 58);
    ctx.restore();
  }
  function drawMarket() {
    ctx.save(); const pulse = state.marketPulse * 4; ctx.translate(market.x, market.y - pulse);
    ctx.fillStyle = 'rgba(69,110,70,.17)'; ctx.beginPath(); ctx.ellipse(0, 48 + pulse, 48, 10, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#d96e54'; roundedRect(-38, -22, 76, 12, 4, '#e77b5b');
    ctx.fillStyle = '#ffdf92'; for (let i=-3;i<4;i++) { ctx.beginPath(); ctx.arc(i*12, -10, 8, Math.PI, 0); ctx.fill(); }
    ctx.fillStyle = '#f4f0dc'; ctx.fillRect(-29, -10, 58, 51); ctx.fillStyle = '#d7795c'; ctx.fillRect(-7, 18, 15, 23);
    ctx.fillStyle = '#fff'; ctx.font = '800 9px DM Sans'; ctx.textAlign = 'center'; ctx.fillText('MARKET', 0, 5);
    ctx.fillStyle = '#647f79'; ctx.font = '700 8px DM Sans'; ctx.fillText('SELL EGGS', 0, 55);
    ctx.restore();
  }
  function drawEggs() {
    state.eggsOnGround.filter(e => !e.collected).forEach(e => {
      ctx.save(); ctx.translate(e.x, e.y + Math.sin(performance.now() / 450 + e.bob) * 1.5);
      ctx.fillStyle = 'rgba(70,109,70,.18)'; ctx.beginPath(); ctx.ellipse(0, 8, 9, 3, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = state.chickenTier > 1 ? '#ffd773' : '#fffaf0'; ctx.strokeStyle = state.chickenTier > 1 ? '#dcae3c' : '#e4d7b9'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(0, 0, 6, 8, -.1, 0, Math.PI*2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.7)'; ctx.beginPath(); ctx.ellipse(-2, -3, 1.5, 3, -.2, 0, Math.PI*2); ctx.fill(); ctx.restore();
    });
  }
  function drawPlayer() {
    const p = state.player, bob = Math.sin(p.bob) * 1.2;
    ctx.save(); ctx.translate(p.x, p.y + bob); ctx.scale(p.dir, 1);
    ctx.fillStyle = 'rgba(52,98,70,.22)'; ctx.beginPath(); ctx.ellipse(0, 20, 15, 5, 0, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#294d58'; ctx.fillRect(-9, 6, 7, 13); ctx.fillRect(2, 6, 7, 13);
    ctx.fillStyle = '#f16850'; ctx.beginPath(); ctx.roundRect(-13, -9, 26, 22, 7); ctx.fill();
    ctx.fillStyle = '#f5bf8d'; ctx.beginPath(); ctx.arc(0, -18, 10, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#e6a66e'; ctx.beginPath(); ctx.arc(0, -22, 10, Math.PI, 0); ctx.fill();
    ctx.fillStyle = '#fff3c7'; ctx.beginPath(); ctx.arc(-3, -24, 10, Math.PI, Math.PI * 1.65); ctx.fill();
    ctx.fillStyle = '#2e4448'; ctx.beginPath(); ctx.arc(4, -18, 1.3, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#efb754'; ctx.beginPath(); ctx.roundRect(11, -4, 10, 13, 3); ctx.fill();
    ctx.restore();
  }
  function drawParticles() { state.dust.forEach(d => { ctx.fillStyle = `rgba(255,242,198,${d.life})`; ctx.beginPath(); ctx.arc(d.x, d.y, d.size, 0, Math.PI*2); ctx.fill(); }); state.particles.forEach(p => { ctx.globalAlpha = Math.max(0,p.life); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x,p.y,p.size,0,Math.PI*2); ctx.fill(); }); ctx.globalAlpha = 1; }
  function drawFloats() { state.floats.forEach(f => { ctx.globalAlpha = Math.min(1, f.life * 2); ctx.fillStyle = f.color; ctx.strokeStyle = 'rgba(74,78,54,.25)'; ctx.lineWidth = 3; ctx.font = '800 11px DM Sans'; ctx.textAlign = 'center'; ctx.strokeText(f.text, f.x, f.y); ctx.fillText(f.text, f.x, f.y); }); ctx.globalAlpha = 1; }

  function gameLoop(t) { const dt = Math.min(.04, (t - lastTime) / 1000 || 0); lastTime = t; update(dt); draw(); requestAnimationFrame(gameLoop); }
  requestAnimationFrame(gameLoop);

  function pointerToWorld(e) {
    const rect = canvas.getBoundingClientRect(); return { x: (e.clientX - rect.left) / scale, y: (e.clientY - rect.top) / scale };
  }
  function setJoystick(e) {
    const rect = $('joystick').getBoundingClientRect(); const cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy; const max = 29, len = Math.hypot(dx,dy); if (len > max) { dx *= max / len; dy *= max / len; }
    state.joystick.x = dx / max; state.joystick.y = dy / max; $('joystickKnob').style.transform = `translate(${dx}px, ${dy}px)`;
  }
  $('joystick').addEventListener('pointerdown', e => { state.joystick.active = true; state.joystick.pointerId = e.pointerId; $('joystick').setPointerCapture(e.pointerId); setJoystick(e); });
  $('joystick').addEventListener('pointermove', e => { if (state.joystick.active && e.pointerId === state.joystick.pointerId) setJoystick(e); });
  ['pointerup','pointercancel','lostpointercapture'].forEach(type => $('joystick').addEventListener(type, () => { state.joystick.active = false; state.joystick.x = 0; state.joystick.y = 0; $('joystickKnob').style.transform = 'translate(0,0)'; }));
  action.button.addEventListener('pointerdown', e => { e.stopPropagation(); if (running) actionNow(); });
  canvas.addEventListener('pointerdown', e => {
    if (!running) return;
    const p = pointerToWorld(e); const hit = state.crops.find(c => c.ready && Math.hypot(c.x-p.x,c.y-p.y)<18);
    if (hit && nearPatch()) harvest();
    else if (nearPatch() && p.x > patch.x-10 && p.x < patch.x+patch.w+10 && p.y > patch.y-10 && p.y < patch.y+patch.h+10) harvest();
  });
  $('startButton').addEventListener('click', () => { running = true; $('startCard').classList.add('hidden'); addToast('Your first harvest is almost ready!'); });
  $('upgradeButton').addEventListener('click', () => { $('upgradeModal').classList.remove('hidden'); updateHUD(); });
  $('closeUpgrade').addEventListener('click', () => $('upgradeModal').classList.add('hidden'));
  $('upgradeModal').addEventListener('click', e => { if (e.target === $('upgradeModal')) $('upgradeModal').classList.add('hidden'); });
  document.querySelectorAll('.upgrade-card').forEach(card => card.addEventListener('click', () => buyUpgrade(card.dataset.upgrade)));
  $('soundButton').addEventListener('click', () => { soundOn = !soundOn; $('soundButton').textContent = soundOn ? '♪' : '×'; addToast(soundOn ? 'Sound on' : 'Sound muted'); });
  updateHUD();
})();