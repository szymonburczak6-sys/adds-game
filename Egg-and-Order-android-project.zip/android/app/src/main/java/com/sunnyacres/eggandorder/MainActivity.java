package com.sunnyacres.eggandorder;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
